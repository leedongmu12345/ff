/* Forge Adventure 멀티플레이 서버
 * - 외부 패키지 없이 Node 기본 모듈만 사용 (npm install 이 비어 있어도 OK)
 * - GET /          → index.html (게임)
 * - GET /healthz   → 상태 확인
 * - WS  /ws?room=  → 멀티플레이 (같은 room 이름끼리 한 방)
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const INDEX = path.join(__dirname, 'index.html');

const MAX_PER_ROOM = 12;      // 방당 최대 인원
const MAX_FRAME = 8 * 1024;   // 클라이언트 → 서버 메시지 최대 크기
const SHARE_RANGE = 800;      // 경험치 공유 거리(px)
const SHARE_RATIO = 0.6;      // 동료가 받는 경험치 비율
const IDLE_MS = 70000;        // 이 시간 동안 아무 신호 없으면 연결 종료

const rooms = new Map();      // roomName -> Set<Client>
let nextId = 1;

/* ---------- HTTP ---------- */
const server = http.createServer((req, res) => {
  const url = (req.url || '/').split('?')[0];
  if (url === '/' || url === '/index.html') {
    fs.readFile(INDEX, (err, buf) => {
      if (err) { res.writeHead(500); res.end('index.html not found'); return; }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
      res.end(buf);
    });
  } else if (url === '/healthz') {
    let n = 0; for (const s of rooms.values()) n += s.size;
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('ok players=' + n);
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('not found');
  }
});

/* ---------- WebSocket 핸드셰이크 ---------- */
server.on('upgrade', (req, socket) => {
  const u = new URL(req.url || '/', 'http://x');
  const key = req.headers['sec-websocket-key'];
  if (u.pathname !== '/ws' || !key || String(req.headers.upgrade || '').toLowerCase() !== 'websocket') {
    socket.destroy(); return;
  }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write(
    'HTTP/1.1 101 Switching Protocols\r\n' +
    'Upgrade: websocket\r\nConnection: Upgrade\r\n' +
    'Sec-WebSocket-Accept: ' + accept + '\r\n\r\n'
  );
  socket.setNoDelay(true);
  let room = (u.searchParams.get('room') || 'main').replace(/[^\w가-힣-]/g, '').slice(0, 20) || 'main';
  new Client(socket, room);
});

/* ---------- 프레임 인코딩 ---------- */
function frame(op, payload) {
  const len = payload.length;
  let head;
  if (len < 126) head = Buffer.from([0x80 | op, len]);
  else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | op; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | op; head[1] = 127; head.writeUInt32BE(0, 2); head.writeUInt32BE(len, 6); }
  return Buffer.concat([head, payload]);
}

/* ---------- 클라이언트 ---------- */
class Client {
  constructor(socket, roomName) {
    this.socket = socket;
    this.roomName = roomName;
    this.id = nextId++;
    this.nick = null;       // hi 메시지 이후에만 방에 들어감
    this.st = null;         // 마지막 상태
    this.buf = Buffer.alloc(0);
    this.frag = null;
    this.alive = true;
    this.lastSeen = Date.now();
    this.tokens = 80; this.tokT = Date.now();
    this.lastChat = 0; this.lastKill = 0;

    socket.on('data', d => this.onData(d));
    socket.on('close', () => this.cleanup());
    socket.on('error', () => this.cleanup());
    socket.on('end', () => this.cleanup());
  }

  onData(d) {
    this.lastSeen = Date.now();
    this.buf = this.buf.length ? Buffer.concat([this.buf, d]) : d;
    if (this.buf.length > MAX_FRAME * 4) { this.close(); return; }
    while (this.alive) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = (b[0] & 0x80) !== 0, op = b[0] & 0x0f, masked = (b[1] & 0x80) !== 0;
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) {
        if (b.length < 10) return;
        if (b.readUInt32BE(2) !== 0) { this.close(); return; }
        len = b.readUInt32BE(6); off = 10;
      }
      if (len > MAX_FRAME) { this.close(); return; }
      if (!masked) { this.close(); return; }       // 클라이언트 프레임은 항상 마스크됨
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4);
      const payload = Buffer.alloc(len);
      for (let i = 0; i < len; i++) payload[i] = b[off + 4 + i] ^ mask[i & 3];
      this.buf = b.subarray(off + 4 + len);
      this.onFrame(op, fin, payload);
    }
  }

  onFrame(op, fin, payload) {
    if (op === 8) { this.close(); return; }                                   // close
    if (op === 9) { this.raw(frame(10, payload)); return; }                   // ping → pong
    if (op === 10) return;                                                    // pong
    if (op === 1 || op === 0) {                                               // text / continuation
      if (op === 1) this.frag = [];
      if (!this.frag) return;
      this.frag.push(payload);
      if (this.frag.reduce((a, c) => a + c.length, 0) > MAX_FRAME) { this.close(); return; }
      if (fin) {
        const text = Buffer.concat(this.frag).toString('utf8'); this.frag = null;
        let m; try { m = JSON.parse(text); } catch (e) { return; }
        if (m && typeof m === 'object') this.onMsg(m);
      }
    }
  }

  /* 초당 메시지 수 제한 (토큰 버킷) */
  allow() {
    const now = Date.now();
    this.tokens = Math.min(80, this.tokens + (now - this.tokT) * 0.06); this.tokT = now;  // 초당 60개 회복
    if (this.tokens < 1) return false;
    this.tokens -= 1; return true;
  }

  onMsg(m) {
    if (!this.allow()) return;
    if (m.t === 'hi') return this.onHi(m);
    if (!this.nick) return;
    if (m.t === 'st') return this.onState(m);
    if (m.t === 'chat') return this.onChat(m);
    if (m.t === 'kill') return this.onKill(m);
  }

  onHi(m) {
    if (this.nick) return;
    const nick = cleanText(m.nick, 8) || ('모험가' + this.id);
    let set = rooms.get(this.roomName);
    if (!set) { set = new Set(); rooms.set(this.roomName, set); }
    if (set.size >= MAX_PER_ROOM) { this.send({ t: 'full', max: MAX_PER_ROOM }); this.close(); return; }
    this.nick = nick;
    const players = [];
    for (const c of set) players.push(c.info());
    set.add(this);
    this.send({ t: 'welcome', id: this.id, room: this.roomName, players });
    this.broadcast({ t: 'join', p: this.info() });
  }

  info() { return Object.assign({ id: this.id, nick: this.nick }, this.st || {}); }

  onState(m) {
    const n = (v, lo, hi) => { v = Number(v); return Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : null; };
    const x = n(m.x, -5000, 10000), y = n(m.y, -1000, 10000);
    if (x === null || y === null) return;
    this.st = {
      x: Math.round(x), y: Math.round(y),
      d: n(m.d, 0, 7) | 0, mv: m.mv ? 1 : 0,
      ci: n(m.ci, 0, 500) | 0, lv: n(m.lv, 0, 9999) | 0,
      hp: Math.round(n(m.hp, 0, 9999999) || 0), mhp: Math.round(n(m.mhp, 1, 9999999) || 1),
      md: n(m.md, 0, 15) | 0
    };
    this.broadcast(Object.assign({ t: 'st', id: this.id }, this.st));
  }

  onChat(m) {
    const now = Date.now();
    if (now - this.lastChat < 600) return;
    const text = cleanText(m.m, 80);
    if (!text) return;
    this.lastChat = now;
    this.broadcast({ t: 'chat', id: this.id, nick: this.nick, m: text }, true);
  }

  /* 몬스터를 잡으면 근처 같은 방 동료에게 경험치 일부를 나눠 준다 */
  onKill(m) {
    const now = Date.now();
    if (now - this.lastKill < 60) return;
    this.lastKill = now;
    const lv = Math.max(1, Math.min(300, Number(m.lv) | 0));
    const boss = m.b ? 1 : 0;
    const exp = Math.max(1, Math.floor((6 + lv * 4) * SHARE_RATIO * (boss ? 3 : 1)));
    const set = rooms.get(this.roomName);
    if (!set || !this.st) return;
    for (const c of set) {
      if (c === this || !c.st) continue;
      if (c.st.md !== this.st.md) continue;                       // 던전/바다/벚꽃 마을 등 모드가 다르면 제외
      if (Math.hypot(c.st.x - this.st.x, c.st.y - this.st.y) > SHARE_RANGE) continue;
      c.send({ t: 'share', nick: this.nick, exp, lv });
    }
  }

  broadcast(obj, includeSelf) {
    const set = rooms.get(this.roomName);
    if (!set) return;
    const data = frame(1, Buffer.from(JSON.stringify(obj)));
    for (const c of set) if (includeSelf || c !== this) c.raw(data);
  }

  send(obj) { this.raw(frame(1, Buffer.from(JSON.stringify(obj)))); }

  raw(buf) {
    const s = this.socket;
    if (!this.alive || !s.writable) return;
    if (s.writableLength > 1024 * 1024) { this.close(); return; }   // 너무 밀리면 끊기
    s.write(buf);
  }

  close() {
    if (!this.alive) return;
    try { this.socket.write(frame(8, Buffer.alloc(0))); } catch (e) {}
    try { this.socket.end(); } catch (e) {}
    setTimeout(() => { try { this.socket.destroy(); } catch (e) {} }, 500);
    this.cleanup();
  }

  cleanup() {
    if (!this.alive) return;
    this.alive = false;
    const set = rooms.get(this.roomName);
    if (set && set.delete(this) && this.nick) {
      const data = frame(1, Buffer.from(JSON.stringify({ t: 'leave', id: this.id, nick: this.nick })));
      for (const c of set) c.raw(data);
      if (!set.size) rooms.delete(this.roomName);
    }
  }
}

function cleanText(v, max) {
  if (typeof v !== 'string') return '';
  return v.replace(/[\u0000-\u001f\u007f<>]/g, '').trim().slice(0, max);
}

/* ---------- 하트비트: 프록시가 연결을 끊지 않도록 주기적으로 ping ---------- */
setInterval(() => {
  const now = Date.now();
  const ping = frame(9, Buffer.alloc(0));
  for (const set of rooms.values()) for (const c of [...set]) {
    if (now - c.lastSeen > IDLE_MS) { c.close(); continue; }
    c.raw(ping);
  }
}, 20000);

server.listen(PORT, () => console.log('Forge server listening on :' + PORT));
